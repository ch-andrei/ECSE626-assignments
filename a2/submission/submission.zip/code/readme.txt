By default, running gmm.py will do segmentation with 2, 4, and 6 GMMs of the Pyramids image.

In the code, almost at the top, you can configure some parameters to change the behaviour:

"""
# GMM segmentation configuration
img2read = imgName2 # image to process
rescale = 1 # rescale ratio, 1 indicates no rescaling
gmmK = 2 # default K, 
gmmMaxIterations = 250 # termination if epsilon criterion isn't reached
gmmFeatureType = "lab" # feature type to run segmentation with
epsilon = 1e-3 # for convergence
epsilonP = 1e-6 # for precision
"""

Scroll all the way down to function main(). You can uncomment the crossvalidation function to run that.